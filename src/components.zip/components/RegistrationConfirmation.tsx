"use client";

import { useEffect, useState } from "react";
import { Button, Card, Row, Col, message } from "antd";
import { useSelector } from "react-redux";
import { RootState } from "@/store/store";
import axios from "axios";
import PaymentSuccess from "./PaymentSuccess";

const generateOrderId = () => `${Math.floor(1000 + Math.random() * 9000)}`;

export const RegistrationConfirmation = ({
  onBack,
  onNext,
}: {
  onBack: () => void;
  onNext: () => void;
}) => {
  const formData = useSelector((state: RootState) => state.form);
  const [snapToken, setSnapToken] = useState<string | null>(null);
  const [orderId, setOrderId] = useState<string | null>(null);
  const [checkoutDate, setCheckoutDate] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [savedFormData, setSavedFormData] = useState<any>(null);
  const [paymentSuccess, setPaymentSuccess] = useState(false); // State untuk pembayaran berhasil

  useEffect(() => {
    const step1Data = localStorage.getItem("registrationStep1Data");
    const step2Data = localStorage.getItem("registrationStep2Data");
    const storedSnapToken = sessionStorage.getItem("snapToken");

    if (step1Data && step2Data) {
      setSavedFormData({
        ...JSON.parse(step1Data),
        ...JSON.parse(step2Data),
      });
    }

    if (storedSnapToken) {
      setSnapToken(storedSnapToken); // Memuat token jika tersedia
    }
    if (!orderId) {
      setOrderId(orderId);
    }
    
  }, []);

  useEffect(() => {
    if (snapToken) {
      window.snap.embed(snapToken, {
        embedId: "snap-container",
        onSuccess: async (result) => {
          console.log("Pembayaran berhasil:", result);
          setOrderId(orderId);
          try {
            await axios.post("/api/saveData", {
              orderId,
              savedFormData,
            });
            message.success("Data berhasil disimpan!");
          } catch (error) {
            console.error("Error saving registration data:", error);
            message.error("Gagal menyimpan data.");
          }
  
          // Set checkoutDate
          const currentDate = new Date().toLocaleDateString("id-ID", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
          });
          setCheckoutDate(currentDate);
  
          // Tandai pembayaran berhasil
          sessionStorage.removeItem("snapToken");
          localStorage.removeItem("currentStep");
          setPaymentSuccess(true); // Memastikan PaymentSuccess dijalankan
        },
        onPending: (result) => {
          console.log("Pembayaran pending:", result);
          message.info("Pembayaran belum selesai.");
          // sessionStorage.removeItem("snapToken");
        },
        onError: (result) => {
          console.error("Kesalahan dalam pembayaran:", result);
          message.error("Pembayaran gagal.");
          sessionStorage.removeItem("snapToken");
        },
        onClose: () => {
          console.log("Pembayaran ditutup oleh pengguna.");
          message.info("Anda menutup proses pembayaran.");
        },
      });
    }
  }, [snapToken]);
  

  const handlePayment = async () => {
    if (isProcessing) {
      message.info("Pembayaran sedang diproses. Silakan tunggu.");
      return;
    }
    if (!savedFormData) {
      message.error("Data pendaftaran tidak ditemukan.");
      return;
    }

    setIsProcessing(true);

    const newOrderId = generateOrderId();
    setOrderId(newOrderId);

    try {
      const response = await axios.post("/api/payment", {
        amount: parseInt(savedFormData?.price.replace(/[Rp\s.]/g, ""), 10),
        orderId: newOrderId,
        customerDetails: {
          first_name: savedFormData?.fullName,
          email: savedFormData?.email,
          phone: savedFormData?.phone,
          address: savedFormData?.address,
          city: savedFormData?.regency,
          country_code: "IDN",
        },
      });

      if (response.data?.token) {
        setSnapToken(response.data.token);
        sessionStorage.setItem("snapToken", response.data.token); 
        sessionStorage.setItem("orderId", newOrderId);// Simpan snapToken di sessionStorage
        message.success("Memuat pembayaran...");
      } else {
        message.error("Gagal mendapatkan Snap Token. Silakan coba lagi.");
      }
    } catch (error) {
      console.error("Error while initiating payment:", error);
      message.error("Gagal memulai transaksi pembayaran.");
    } finally {
      setIsProcessing(false);
    }
  };

  if (paymentSuccess) {
    return (
      <PaymentSuccess
        orderId={orderId!}
        fullName={savedFormData?.fullName}
        totalPaid={savedFormData?.price}
        checkoutDate={checkoutDate!}
        email={savedFormData?.email!}
        onNext={onNext}
      />
    );
  }
  

  return (
    <div className="confirmation-container">
      <Card title="Konfirmasi Pendaftaran" className="confirmation-card">
        <Row>
          <Col span={24}>
            <div
              style={{
                padding: "20px",
                border: "1px solid #f0f0f0",
                borderRadius: "8px",
                marginBottom: "20px",
              }}
            >
              <p><strong>Full Name:</strong> {savedFormData?.fullName}</p>
              <p><strong>Email:</strong> {savedFormData?.email}</p>
              <p><strong>Price:</strong> {savedFormData?.price}</p>
            </div>
          </Col>
          <Col span={24}>
            <div style={{ marginBottom: "20px" }}>
              <Button onClick={onBack}>Previous</Button>
              <Button
                type="primary"
                onClick={handlePayment}
                loading={isProcessing}
                style={{ marginLeft: "10px" }}
              >
                Proceed to Payment
              </Button>
            </div>
          </Col>
          <Col span={24}>
            <div
              id="snap-container"
              style={{
                width: "100%",
                minHeight: "500px",
                border: "1px solid #d9d9d9",
                borderRadius: "8px",
                overflow: "hidden",
              }}
            ></div>
          </Col>
        </Row>
      </Card>
    </div>
  );
};

export default RegistrationConfirmation;
